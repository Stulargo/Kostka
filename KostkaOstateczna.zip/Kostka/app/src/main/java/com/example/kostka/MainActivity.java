package com.example.kostka;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import java.util.Random;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    private int liczba;
    private int suma;
    private int liczbaRzutow;
    private String historia = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.number);

        if (savedInstanceState != null) {
            suma = savedInstanceState.getInt("suma", 0);
            liczbaRzutow = savedInstanceState.getInt("liczbaRzutow", 0);
            historia = savedInstanceState.getString("historia", "");
        }
        textView.setText("Losowanie");
        Handler handler = new Handler();
        handler.postDelayed(() -> {

            Random rand = new Random();
            liczba = rand.nextInt(6) + 1;

            suma += liczba;
            liczbaRzutow++;

            double srednia = (double) suma / liczbaRzutow;

            historia += String.valueOf(liczba) + ",";

            textView.setText(
                    "Wylosowano: " + liczba +
                            "\nSuma: " + suma +
                            "\nŚrednia: " + String.format("%.2f", srednia) +
                            "\nHistoria: " + historia
            );
        }, 1500);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("suma", suma);
        outState.putInt("liczbaRzutow", liczbaRzutow);
        outState.putString("historia", historia);
    }
}
