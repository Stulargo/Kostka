package com.example.kostka;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int liczba;
    private int suma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            suma = savedInstanceState.getInt("suma", 0);
        } else {
            suma = 0;
        }

        Random rand = new Random();
        liczba = rand.nextInt(6) + 1;

        suma += liczba;

        TextView textView = findViewById(R.id.number);

        textView.setText("Wylosowano: " + liczba + "\nSuma: " + suma);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("suma", suma);
    }
}
